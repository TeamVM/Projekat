import { Component, OnInit } from '@angular/core';
import { RentaCompany } from '../_models/rentaCompany';
import { ActivatedRoute, Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { Car } from '../_models/Car';
import { ltLocale } from 'ngx-bootstrap/chronos/i18n/lt';
import { CarCompanyService } from '../services/carcompany.service';
import { CarService } from '../services/car.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-company1re',
  templateUrl: './company1re.component.html',
  styleUrls: ['./company1re.component.scss']
})
export class Company1reComponent implements OnInit {
  editButton=true;
  editCompany=true;
  updateButton=true;
  idComp=null;
  rentadmin = true;

  ukupnaCenaAuta = [];

  rentaCompany: RentaCompany= {
      id: '',
      name: '',
      adresa: '',
      promo: '',
      filijale:'',
      ocena: '' ,
      listaAuta:[]
  };
  tipUsera:string;
  constructor(private route: ActivatedRoute, 
    private service: CarCompanyService,
     private carService: CarService, 
     private router:Router, private authService: AuthService) { }

  ngOnInit(): void {
    this.route.params.subscribe(res => { 
      this.idComp=res.id;
      this.service.getCompanyById(res.id).subscribe((res) => {  this.rentaCompany = res;   } );
    });

    this.authService.data.subscribe(_res => { 
      this.tipUsera = _res;
      if(_res != "rentadmin") { 
        this.editButton = false;
        this.updateButton = false;
        this.rentadmin = false;
      }
    });

  }

  rezervisi(auto: any) {
    this.carService.reserveCar(auto).subscribe((result) => { 
      if (result) {
        this.router.navigate(['/rezervisaoauto']);
      } else {
        this.router.navigate(['/nijerezervisaoauto']);
      }
    });
  }


  obrisi(idAuta) {
    this.carService.deleteCar(idAuta).subscribe((result) => { 
      if (result) {
        this.router.navigate(['/listakompanija']);
      }
    });
  }

  obrisiKompaniju(kompanja) {
    this.service.deleteCompany(kompanja).subscribe((result) => {
      this.router.navigate(['/listakompanija']);
    })
  }
  edit(){
    this.rentaCompany.id=this.idComp;
    console.log(this.rentaCompany);
    this.editCompany=false;
  }
  update(){
    
    this.service.editCompany(this.rentaCompany).subscribe((result)=>{
      console.log(this.rentaCompany);
    })
  }

  changedDate(index: number) {
    if (this.rentaCompany.listaAuta[index].datumOd != undefined && this.rentaCompany.listaAuta[index].datumDo != undefined) {
      const oneDay = 24 * 60 * 60 * 1000; // hours * minutes * seconds * millisecondss
      const dateFrom = new Date(this.rentaCompany.listaAuta[index].datumOd);
      const dateTo = new Date(this.rentaCompany.listaAuta[index].datumDo);
      let brojDana = Math.round(Math.abs((dateTo.getTime() - dateFrom.getTime()) / oneDay));
      this.ukupnaCenaAuta[index] = Number(this.rentaCompany.listaAuta[index].cena) * brojDana;
    }
  }
}    
